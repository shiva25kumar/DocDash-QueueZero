import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import type { AuthUser, UserRole } from '../../src/types/clinic.ts';
import type { AuditLogger } from '../logger.ts';
import { ForbiddenError, UnauthorizedError } from '../errors.ts';

const JWT_SECRET = process.env.JWT_SECRET ?? 'docdash-queuezero-dev-secret-change-in-prod';
export const AUTH_COOKIE_NAME = 'docdash_token';
export const CSRF_COOKIE_NAME = 'docdash_csrf';

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export function isSecureRequest(req: Request): boolean {
  return req.secure || req.headers['x-forwarded-proto'] === 'https';
}

export function signAuthToken(user: AuthUser): string {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      doctorId: user.doctorId,
    },
    JWT_SECRET,
    { expiresIn: '12h' }
  );
}

export function verifyAuthToken(token: string): AuthUser {
  const decoded = jwt.verify(token, JWT_SECRET) as AuthUser;
  return {
    id: decoded.id,
    email: decoded.email,
    name: decoded.name,
    role: decoded.role,
    doctorId: decoded.doctorId ?? null,
  };
}

export function attachOptionalUser(
  req: AuthenticatedRequest,
  _res: Response,
  next: NextFunction
): void {
  const cookieToken = req.cookies?.[AUTH_COOKIE_NAME] as string | undefined;
  const authHeader = req.headers.authorization;
  const bearerToken =
    authHeader && authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : undefined;
  const token = cookieToken || bearerToken;

  if (!token) {
    next();
    return;
  }

  try {
    req.user = verifyAuthToken(token);
  } catch {
    req.user = undefined;
  }
  next();
}

export function requireAuth(audit: AuditLogger) {
  return (req: AuthenticatedRequest, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      audit.record({
        event: 'AUTH_UNAUTHORIZED',
        actorRole: 'anonymous',
        actorName: 'unauthenticated',
        details: { path: req.path, method: req.method },
      });
      next(new UnauthorizedError('Authentication required to access clinical controls'));
      return;
    }
    next();
  };
}

export function requireRole(audit: AuditLogger, ...allowedRoles: UserRole[]) {
  return (req: AuthenticatedRequest, _res: Response, next: NextFunction): void => {
    if (!req.user) {
      audit.record({
        event: 'AUTH_UNAUTHORIZED',
        actorRole: 'anonymous',
        actorName: 'unauthenticated',
        details: { path: req.path, method: req.method },
      });
      next(new UnauthorizedError('Authentication required'));
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      audit.record({
        event: 'AUTH_FORBIDDEN',
        actorRole: req.user.role,
        actorName: req.user.name,
        doctorId: req.user.doctorId,
        details: {
          path: req.path,
          method: req.method,
          requiredRoles: allowedRoles,
        },
      });
      next(
        new ForbiddenError(
          `Role '${req.user.role}' is not authorized for this operation`
        )
      );
      return;
    }

    next();
  };
}

export function generateCsrfToken(): string {
  return crypto.randomBytes(24).toString('hex');
}

export function csrfProtection(audit: AuditLogger) {
  return (req: AuthenticatedRequest, _res: Response, next: NextFunction): void => {
    const method = req.method.toUpperCase();
    if (method === 'GET' || method === 'HEAD' || method === 'OPTIONS') {
      next();
      return;
    }

    // Login and logout bootstrap or clear session tokens
    if (req.path === '/api/auth/login' || req.path === '/api/auth/logout') {
      next();
      return;
    }

    const cookieToken = req.cookies?.[CSRF_COOKIE_NAME] as string | undefined;
    const headerToken = req.headers['x-csrf-token'] as string | undefined;

    if (!cookieToken || !headerToken) {
      audit.record({
        event: 'CSRF_VALIDATION_FAILED',
        actorRole: req.user?.role ?? 'anonymous',
        actorName: req.user?.name ?? 'unauthenticated',
        details: { path: req.path, method, reason: 'missing_token' },
      });
      next(new ForbiddenError('Invalid or missing CSRF token'));
      return;
    }

    const a = Buffer.from(cookieToken);
    const b = Buffer.from(headerToken);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
      audit.record({
        event: 'CSRF_VALIDATION_FAILED',
        actorRole: req.user?.role ?? 'anonymous',
        actorName: req.user?.name ?? 'unauthenticated',
        details: { path: req.path, method, reason: 'mismatch' },
      });
      next(new ForbiddenError('CSRF token mismatch'));
      return;
    }

    next();
  };
}

export function createBookingRateLimiter(maxRequests = 30, windowMs = 60_000) {
  return rateLimit({
    windowMs,
    max: maxRequests,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (_req, res) => {
      res.status(429).json({
        success: false,
        error: {
          code: 'RATE_LIMIT_EXCEEDED',
          message: 'Too many booking requests. Please wait a minute before booking again.',
        },
      });
    },
  });
}
