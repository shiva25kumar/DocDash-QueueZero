import fs from 'node:fs';
import { Router, type RequestHandler } from 'express';
import { z } from 'zod';
import type { QueueService } from '../services/queueService.ts';
import type { AuthenticatedRequest } from '../middleware/auth.ts';
import { NotFoundError, ValidationError } from '../errors.ts';

const bookingSchema = z.object({
  clinicId: z.coerce.number().int().positive(),
  doctorId: z.coerce.number().int().positive(),
  shift: z.enum(['morning', 'evening']),
  patientName: z.string().trim().min(2, 'Patient name is required').max(120),
  patientPhone: z
    .string()
    .trim()
    .min(7, 'Valid contact phone is required')
    .max(30),
  symptoms: z.string().trim().max(500).optional().default(''),
});

const checkinSchema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180),
});

export function createAppointmentRoutes(
  queueService: QueueService,
  bookingRateLimiter: RequestHandler
): Router {
  const router = Router();

  router.post('/', bookingRateLimiter, (req: AuthenticatedRequest, res, next) => {
    try {
      const payload = bookingSchema.parse(req.body);
      const appointment = queueService.bookAppointmentAndToken({
        ...payload,
        actor: req.user,
      });
      res.status(201).json({ success: true, appointment });
    } catch (err) {
      next(err);
    }
  });

  router.get('/', (req, res, next) => {
    try {
      const phone = typeof req.query.phone === 'string' ? req.query.phone : undefined;
      const idsRaw = typeof req.query.ids === 'string' ? req.query.ids : undefined;
      const ids = idsRaw
        ? idsRaw
            .split(',')
            .map((v) => Number(v.trim()))
            .filter((n) => Number.isInteger(n) && n > 0)
        : undefined;

      const appointments = queueService.getAppointmentsList({ phone, ids });
      res.json({ success: true, appointments });
    } catch (err) {
      next(err);
    }
  });

  router.get('/:id', (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        throw new ValidationError('Invalid appointment identifier');
      }
      const appointment = queueService.getAppointmentDetail(id);
      res.json({ success: true, appointment });
    } catch (err) {
      next(err);
    }
  });

  router.post('/:id/checkin', (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        throw new ValidationError('Invalid appointment identifier');
      }
      const { latitude, longitude } = checkinSchema.parse(req.body);
      const result = queueService.checkInWithGeolocation(id, latitude, longitude);
      res.json({ success: true, ...result });
    } catch (err) {
      next(err);
    }
  });

  router.get('/:id/prescription/download', (req, res, next) => {
    try {
      const id = Number(req.params.id);
      if (!Number.isInteger(id) || id <= 0) {
        throw new ValidationError('Invalid appointment identifier');
      }
      const meta = queueService.getPrescriptionDownloadMeta(id);
      if (!fs.existsSync(meta.storedPath)) {
        throw new NotFoundError('Prescription file no longer exists on disk');
      }
      res.setHeader('Content-Type', meta.mimeType);
      res.setHeader('Content-Disposition', `attachment; filename="${meta.fileName.replace(/"/g, '')}"`);
      fs.createReadStream(meta.storedPath).pipe(res);
    } catch (err) {
      next(err);
    }
  });

  return router;
}
