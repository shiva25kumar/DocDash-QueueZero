import { Router } from 'express';
import type { QueueService } from '../services/queueService.ts';

export function createDirectoryRoutes(queueService: QueueService): Router {
  const router = Router();

  router.get('/clinics', (_req, res, next) => {
    try {
      res.json({ success: true, clinics: queueService.getClinics() });
    } catch (err) {
      next(err);
    }
  });

  router.get('/specialties', (_req, res, next) => {
    try {
      res.json({ success: true, specialties: queueService.getSpecialties() });
    } catch (err) {
      next(err);
    }
  });

  router.get('/doctors', (req, res, next) => {
    try {
      const clinicId = req.query.clinicId ? Number(req.query.clinicId) : undefined;
      const specialty =
        typeof req.query.specialty === 'string' ? req.query.specialty : undefined;
      const doctors = queueService.getDoctors({
        clinicId: clinicId && Number.isFinite(clinicId) ? clinicId : undefined,
        specialty,
      });
      res.json({ success: true, doctors });
    } catch (err) {
      next(err);
    }
  });

  router.get('/analytics/heatmap', (req, res, next) => {
    try {
      const clinicId = req.query.clinicId ? Number(req.query.clinicId) : undefined;
      const cells = queueService.getClinicHeatmapData(
        clinicId && Number.isFinite(clinicId) ? clinicId : undefined
      );
      res.json({ success: true, heatmap: cells });
    } catch (err) {
      next(err);
    }
  });

  return router;
}
