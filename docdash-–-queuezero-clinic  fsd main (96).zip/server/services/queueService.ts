import type Database from 'better-sqlite3';
import type {
  AuditLogEntry,
  AuthUser,
  Clinic,
  ComputedTokenSnapshot,
  Doctor,
  DoctorQueueBoard,
  DoctorStatusType,
  HeatmapCell,
  PaginatedTokenHistory,
  PatientAppointmentDetail,
  PrescriptionAttachment,
  QueueTokenItem,
  ShiftType,
  Specialty,
  TokenStatusType,
} from '../../src/types/clinic.ts';
import {
  calculateEwma,
  clampConsultationDuration,
  computeQueueWaitSnapshots,
  generateNextTokenNumber,
  SMS_ALERT_TOKEN_DISTANCE,
} from '../../src/utils/queueEstimator.ts';
import { CLINIC_CHECKIN_RADIUS_METERS, isWithinCheckInRadius } from '../../src/utils/geo.ts';
import type { AuditLogger } from '../logger.ts';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../errors.ts';

interface DoctorRow {
  id: number;
  clinic_id: number;
  clinic_name: string;
  clinic_neighborhood: string;
  clinic_address: string;
  clinic_latitude: number;
  clinic_longitude: number;
  specialty_id: number;
  specialty_name: string;
  name: string;
  credentials: string;
  room_number: string;
  consultation_fee: number;
  base_avg_minutes: number;
  ewma_minutes: number;
  recent_durations_json: string;
  morning_status: DoctorStatusType;
  evening_status: DoctorStatusType;
  morning_delay_minutes: number;
  evening_delay_minutes: number;
}

interface TokenRow {
  id: number;
  appointment_id: number;
  clinic_id: number;
  doctor_id: number;
  shift: ShiftType;
  token_number: number;
  status: TokenStatusType;
  is_emergency: number;
  priority_rank: number;
  patient_name: string;
  patient_phone: string;
  checked_in: number;
  checked_in_at: string | null;
  called_at: string | null;
  completed_at: string | null;
  consultation_duration: number | null;
  sms_alert_sent: number;
  created_at: string;
}

function mapDoctorRow(row: DoctorRow): Doctor {
  return {
    id: row.id,
    clinicId: row.clinic_id,
    clinicName: row.clinic_name,
    clinicNeighborhood: row.clinic_neighborhood,
    clinicAddress: row.clinic_address,
    clinicLatitude: row.clinic_latitude,
    clinicLongitude: row.clinic_longitude,
    specialtyId: row.specialty_id,
    specialtyName: row.specialty_name,
    name: row.name,
    credentials: row.credentials,
    roomNumber: row.room_number,
    consultationFee: row.consultation_fee,
    baseAvgMinutes: row.base_avg_minutes,
    ewmaMinutes: row.ewma_minutes,
    recentDurations: JSON.parse(row.recent_durations_json) as number[],
    morningStatus: row.morning_status,
    eveningStatus: row.evening_status,
    morningDelayMinutes: row.morning_delay_minutes,
    eveningDelayMinutes: row.evening_delay_minutes,
  };
}

function mapTokenRow(row: TokenRow): QueueTokenItem {
  return {
    id: row.id,
    appointmentId: row.appointment_id,
    clinicId: row.clinic_id,
    doctorId: row.doctor_id,
    shift: row.shift,
    tokenNumber: row.token_number,
    status: row.status,
    isEmergency: row.is_emergency === 1,
    priorityRank: row.priority_rank,
    patientName: row.patient_name,
    patientPhone: row.patient_phone,
    checkedIn: row.checked_in === 1,
    checkedInAt: row.checked_in_at,
    calledAt: row.called_at,
    completedAt: row.completed_at,
    consultationDuration: row.consultation_duration,
    smsAlertSent: row.sms_alert_sent === 1,
    createdAt: row.created_at,
  };
}

export class QueueService {
  private db: Database.Database;
  private audit: AuditLogger;
  private onQueueChanged?: (doctorId: number, shift: ShiftType) => void;

  constructor(
    db: Database.Database,
    audit: AuditLogger,
    onQueueChanged?: (doctorId: number, shift: ShiftType) => void
  ) {
    this.db = db;
    this.audit = audit;
    this.onQueueChanged = onQueueChanged;
  }

  private notifyChange(doctorId: number, shift: ShiftType): void {
    if (this.onQueueChanged) {
      this.onQueueChanged(doctorId, shift);
    }
  }

  private assertDoctorOwnership(actor: AuthUser, doctorId: number): void {
    if (actor.role === 'doctor' && actor.doctorId !== null && actor.doctorId !== doctorId) {
      this.audit.record({
        event: 'AUTH_DOCTOR_QUEUE_MISMATCH',
        actorRole: actor.role,
        actorName: actor.name,
        doctorId,
        details: { assignedDoctorId: actor.doctorId, requestedDoctorId: doctorId },
      });
      throw new ForbiddenError('Doctors can only manage their own assigned consultation queue');
    }
  }

  getClinics(): Clinic[] {
    return this.db
      .prepare('SELECT id, name, code, address, neighborhood, phone, latitude, longitude FROM clinics ORDER BY id ASC')
      .all() as Clinic[];
  }

  getSpecialties(): Specialty[] {
    return this.db
      .prepare('SELECT id, name, description FROM specialties ORDER BY id ASC')
      .all() as Specialty[];
  }

  getDoctors(filters?: { clinicId?: number; specialty?: string }): Doctor[] {
    const conditions: string[] = [];
    const params: Record<string, unknown> = {};

    if (filters?.clinicId) {
      conditions.push('d.clinic_id = @clinicId');
      params.clinicId = filters.clinicId;
    }
    if (filters?.specialty && filters.specialty !== 'All') {
      conditions.push('s.name = @specialty');
      params.specialty = filters.specialty;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const rows = this.db
      .prepare(`
        SELECT
          d.*,
          c.name AS clinic_name,
          c.neighborhood AS clinic_neighborhood,
          c.address AS clinic_address,
          c.latitude AS clinic_latitude,
          c.longitude AS clinic_longitude,
          s.name AS specialty_name
        FROM doctors d
        JOIN clinics c ON c.id = d.clinic_id
        JOIN specialties s ON s.id = d.specialty_id
        ${whereClause}
        ORDER BY d.id ASC
      `)
      .all(params) as DoctorRow[];

    return rows.map(mapDoctorRow);
  }

  getDoctorById(doctorId: number): Doctor {
    const row = this.db
      .prepare(`
        SELECT
          d.*,
          c.name AS clinic_name,
          c.neighborhood AS clinic_neighborhood,
          c.address AS clinic_address,
          c.latitude AS clinic_latitude,
          c.longitude AS clinic_longitude,
          s.name AS specialty_name
        FROM doctors d
        JOIN clinics c ON c.id = d.clinic_id
        JOIN specialties s ON s.id = d.specialty_id
        WHERE d.id = ?
      `)
      .get(doctorId) as DoctorRow | undefined;

    if (!row) {
      throw new NotFoundError(`Doctor #${doctorId} not found`);
    }
    return mapDoctorRow(row);
  }

  private getTokensForQueue(doctorId: number, shift: ShiftType): QueueTokenItem[] {
    const rows = this.db
      .prepare(`
        SELECT
          qt.*,
          a.patient_name,
          a.patient_phone
        FROM queue_tokens qt
        JOIN appointments a ON a.id = qt.appointment_id
        WHERE qt.doctor_id = ? AND qt.shift = ?
        ORDER BY qt.token_number ASC
      `)
      .all(doctorId, shift) as TokenRow[];

    return rows.map(mapTokenRow);
  }

  getDoctorQueueBoard(doctorId: number, shift: ShiftType): DoctorQueueBoard {
    const doctor = this.getDoctorById(doctorId);
    const tokens = this.getTokensForQueue(doctorId, shift);
    const doctorStatus = shift === 'morning' ? doctor.morningStatus : doctor.eveningStatus;
    const offsetDelayMinutes =
      shift === 'morning' ? doctor.morningDelayMinutes : doctor.eveningDelayMinutes;

    const computed = computeQueueWaitSnapshots({
      tokens,
      dynamicAvgMinutes: doctor.ewmaMinutes,
      offsetDelayMinutes,
    });

    const holdingTokens = tokens.filter((t) => t.status === 'holding');
    const completedCount = tokens.filter((t) => t.status === 'completed').length;
    const nextAvailableTokenNumber = generateNextTokenNumber(tokens.map((t) => t.tokenNumber));

    return {
      doctor,
      shift,
      doctorStatus,
      offsetDelayMinutes,
      ewmaMinutes: doctor.ewmaMinutes,
      activeToken: computed.activeToken,
      nextToken: computed.nextToken,
      waitingTokens: computed.waitingTokens,
      holdingTokens,
      completedCount,
      nextAvailableTokenNumber,
    };
  }

  getAllQueueBoards(filters?: {
    clinicId?: number;
    specialty?: string;
    shift?: ShiftType;
  }): DoctorQueueBoard[] {
    const doctors = this.getDoctors({
      clinicId: filters?.clinicId,
      specialty: filters?.specialty,
    });
    const shift: ShiftType = filters?.shift ?? 'morning';
    return doctors.map((doc) => this.getDoctorQueueBoard(doc.id, shift));
  }

  private markTwoAwaySmsAlerts(doctorId: number, shift: ShiftType): void {
    const board = this.getDoctorQueueBoard(doctorId, shift);
    const updateSmsStmt = this.db.prepare(
      'UPDATE queue_tokens SET sms_alert_sent = 1 WHERE id = ? AND sms_alert_sent = 0'
    );

    for (const token of board.waitingTokens) {
      if (token.patientsAhead === SMS_ALERT_TOKEN_DISTANCE && !token.smsAlertSent) {
        const res = updateSmsStmt.run(token.id);
        if (res.changes > 0) {
          this.audit.record({
            event: 'SMS_ALERT_TRIGGERED',
            actorRole: 'system',
            actorName: 'queue-monitor',
            doctorId,
            tokenNumber: token.tokenNumber,
            details: {
              shift,
              patientName: token.patientName,
              patientPhone: token.patientPhone,
              message: 'Please arrive at the clinic now!',
            },
          });
        }
      }
    }
  }

  bookAppointmentAndToken(input: {
    clinicId: number;
    doctorId: number;
    shift: ShiftType;
    patientName: string;
    patientPhone: string;
    symptoms?: string;
    actor?: AuthUser;
  }): PatientAppointmentDetail {
    const clinic = this.db
      .prepare('SELECT id, name, code, address, neighborhood, phone, latitude, longitude FROM clinics WHERE id = ?')
      .get(input.clinicId) as Clinic | undefined;
    if (!clinic) {
      throw new NotFoundError(`Clinic #${input.clinicId} not found`);
    }

    const doctor = this.getDoctorById(input.doctorId);
    if (doctor.clinicId !== input.clinicId) {
      throw new ValidationError(
        `${doctor.name} practices at ${doctor.clinicName}, not ${clinic.name}`
      );
    }

    const normalizedPhone = input.patientPhone.trim();
    const normalizedName = input.patientName.trim();

    const tx = this.db.transaction(() => {
      const existingActive = this.db
        .prepare(`
          SELECT qt.token_number
          FROM queue_tokens qt
          JOIN appointments a ON a.id = qt.appointment_id
          WHERE qt.doctor_id = ? AND qt.clinic_id = ? AND qt.shift = ?
            AND LOWER(TRIM(a.patient_phone)) = LOWER(?)
            AND qt.status IN ('waiting', 'in_consultation')
          LIMIT 1
        `)
        .get(input.doctorId, input.clinicId, input.shift, normalizedPhone) as
        | { token_number: number }
        | undefined;

      if (existingActive) {
        throw new ConflictError(
          `An active appointment (Token #${existingActive.token_number}) already exists for phone ${normalizedPhone} with ${doctor.name} (${input.shift} shift)`
        );
      }

      const existingNumbers = (
        this.db
          .prepare(
            'SELECT token_number FROM queue_tokens WHERE clinic_id = ? AND doctor_id = ? AND shift = ?'
          )
          .all(input.clinicId, input.doctorId, input.shift) as Array<{ token_number: number }>
      ).map((r) => r.token_number);

      const nextTokenNumber = generateNextTokenNumber(existingNumbers);
      const now = new Date().toISOString();

      const apptRes = this.db
        .prepare(`
          INSERT INTO appointments (clinic_id, doctor_id, shift, patient_name, patient_phone, symptoms, booked_at)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          input.clinicId,
          input.doctorId,
          input.shift,
          normalizedName,
          normalizedPhone,
          (input.symptoms ?? '').trim(),
          now
        );

      const appointmentId = Number(apptRes.lastInsertRowid);

      this.db
        .prepare(`
          INSERT INTO queue_tokens (
            appointment_id, clinic_id, doctor_id, shift, token_number, status,
            is_emergency, priority_rank, checked_in, sms_alert_sent, created_at
          ) VALUES (?, ?, ?, ?, ?, 'waiting', 0, 100, 0, 0, ?)
        `)
        .run(appointmentId, input.clinicId, input.doctorId, input.shift, nextTokenNumber, now);

      return { appointmentId, nextTokenNumber };
    });

    const { appointmentId, nextTokenNumber } = tx();
    this.markTwoAwaySmsAlerts(input.doctorId, input.shift);

    this.audit.record({
      event: 'APPOINTMENT_BOOKED',
      actorRole: input.actor?.role ?? 'patient',
      actorName: input.actor?.name ?? normalizedName,
      doctorId: input.doctorId,
      tokenNumber: nextTokenNumber,
      details: {
        appointmentId,
        clinicId: input.clinicId,
        shift: input.shift,
        patientPhone: normalizedPhone,
      },
    });

    this.notifyChange(input.doctorId, input.shift);
    return this.getAppointmentDetail(appointmentId);
  }

  getAppointmentDetail(appointmentId: number): PatientAppointmentDetail {
    const row = this.db
      .prepare(`
        SELECT
          a.id AS appointment_id,
          a.clinic_id,
          a.doctor_id,
          a.shift,
          a.patient_name,
          a.patient_phone,
          a.symptoms,
          a.booked_at,
          qt.id AS token_id,
          qt.token_number,
          qt.status,
          qt.is_emergency,
          qt.checked_in,
          qt.checked_in_at,
          qt.sms_alert_sent
        FROM appointments a
        JOIN queue_tokens qt ON qt.appointment_id = a.id
        WHERE a.id = ?
      `)
      .get(appointmentId) as
      | {
          appointment_id: number;
          clinic_id: number;
          doctor_id: number;
          shift: ShiftType;
          patient_name: string;
          patient_phone: string;
          symptoms: string;
          booked_at: string;
          token_id: number;
          token_number: number;
          status: TokenStatusType;
          is_emergency: number;
          checked_in: number;
          checked_in_at: string | null;
          sms_alert_sent: number;
        }
      | undefined;

    if (!row) {
      throw new NotFoundError(`Appointment #${appointmentId} not found`);
    }

    const clinic = this.db
      .prepare('SELECT id, name, code, address, neighborhood, phone, latitude, longitude FROM clinics WHERE id = ?')
      .get(row.clinic_id) as Clinic;

    const board = this.getDoctorQueueBoard(row.doctor_id, row.shift);
    const snapshot: ComputedTokenSnapshot | undefined =
      board.activeToken?.id === row.token_id
        ? board.activeToken
        : board.waitingTokens.find((t) => t.id === row.token_id);

    const prescriptionRow = this.db
      .prepare(`
        SELECT id, appointment_id, doctor_id, file_name, mime_type, file_size, notes, uploaded_at
        FROM prescriptions
        WHERE appointment_id = ?
      `)
      .get(row.appointment_id) as
      | {
          id: number;
          appointment_id: number;
          doctor_id: number;
          file_name: string;
          mime_type: string;
          file_size: number;
          notes: string;
          uploaded_at: string;
        }
      | undefined;

    const prescription: PrescriptionAttachment | null = prescriptionRow
      ? {
          id: prescriptionRow.id,
          appointmentId: prescriptionRow.appointment_id,
          doctorId: prescriptionRow.doctor_id,
          fileName: prescriptionRow.file_name,
          mimeType: prescriptionRow.mime_type,
          fileSize: prescriptionRow.file_size,
          notes: prescriptionRow.notes,
          uploadedAt: prescriptionRow.uploaded_at,
        }
      : null;

    return {
      appointmentId: row.appointment_id,
      tokenId: row.token_id,
      tokenNumber: row.token_number,
      shift: row.shift,
      status: row.status,
      isEmergency: row.is_emergency === 1,
      patientName: row.patient_name,
      patientPhone: row.patient_phone,
      symptoms: row.symptoms,
      bookedAt: row.booked_at,
      checkedIn: row.checked_in === 1,
      checkedInAt: row.checked_in_at,
      smsAlertSent: row.sms_alert_sent === 1,
      clinic,
      doctor: {
        id: board.doctor.id,
        name: board.doctor.name,
        credentials: board.doctor.credentials,
        specialtyName: board.doctor.specialtyName,
        roomNumber: board.doctor.roomNumber,
        consultationFee: board.doctor.consultationFee,
        ewmaMinutes: board.ewmaMinutes,
        status: board.doctorStatus,
        offsetDelayMinutes: board.offsetDelayMinutes,
      },
      currentlyServingTokenNumber: board.activeToken?.tokenNumber ?? null,
      queuePosition: snapshot?.queuePosition ?? null,
      patientsAhead: snapshot?.patientsAhead ?? null,
      estimatedWaitMinutes: snapshot?.estimatedWaitMinutes ?? null,
      shouldTriggerSmsAlert: snapshot?.shouldTriggerSmsAlert ?? false,
      prescription,
    };
  }

  getAppointmentsList(filters?: { phone?: string; ids?: number[] }): PatientAppointmentDetail[] {
    let rows: Array<{ id: number }> = [];

    if (filters?.ids && filters.ids.length > 0) {
      const placeholders = filters.ids.map(() => '?').join(',');
      rows = this.db
        .prepare(`SELECT id FROM appointments WHERE id IN (${placeholders}) ORDER BY id DESC`)
        .all(...filters.ids) as Array<{ id: number }>;
    } else if (filters?.phone && filters.phone.trim()) {
      rows = this.db
        .prepare(
          'SELECT id FROM appointments WHERE LOWER(TRIM(patient_phone)) = LOWER(TRIM(?)) ORDER BY id DESC'
        )
        .all(filters.phone) as Array<{ id: number }>;
    } else {
      rows = this.db
        .prepare(`
          SELECT a.id
          FROM appointments a
          JOIN queue_tokens qt ON qt.appointment_id = a.id
          WHERE qt.status IN ('waiting', 'in_consultation', 'holding')
          ORDER BY a.id DESC
          LIMIT 25
        `)
        .all() as Array<{ id: number }>;
    }

    return rows.map((r) => this.getAppointmentDetail(r.id));
  }

  callNextPatient(doctorId: number, shift: ShiftType, actor: AuthUser): {
    calledToken: ComputedTokenSnapshot | null;
    board: DoctorQueueBoard;
  } {
    this.assertDoctorOwnership(actor, doctorId);
    this.getDoctorById(doctorId);

    const tx = this.db.transaction(() => {
      const now = new Date().toISOString();
      const currentActive = this.db
        .prepare(`
          SELECT id, token_number
          FROM queue_tokens
          WHERE doctor_id = ? AND shift = ? AND status = 'in_consultation'
          LIMIT 1
        `)
        .get(doctorId, shift) as { id: number; token_number: number } | undefined;

      if (currentActive) {
        this.db
          .prepare(`
            UPDATE queue_tokens
            SET status = 'completed', completed_at = ?
            WHERE id = ?
          `)
          .run(now, currentActive.id);
      }

      const nextWaiting = this.db
        .prepare(`
          SELECT id, token_number
          FROM queue_tokens
          WHERE doctor_id = ? AND shift = ? AND status = 'waiting'
          ORDER BY is_emergency DESC, priority_rank ASC, token_number ASC
          LIMIT 1
        `)
        .get(doctorId, shift) as { id: number; token_number: number } | undefined;

      if (nextWaiting) {
        this.db
          .prepare(`
            UPDATE queue_tokens
            SET status = 'in_consultation', called_at = ?, checked_in = 1, checked_in_at = COALESCE(checked_in_at, ?)
            WHERE id = ?
          `)
          .run(now, now, nextWaiting.id);
      }

      const statusCol = shift === 'morning' ? 'morning_status' : 'evening_status';
      this.db
        .prepare(`UPDATE doctors SET ${statusCol} = 'In Consultation' WHERE id = ?`)
        .run(doctorId);

      return {
        previousTokenNumber: currentActive?.token_number ?? null,
        calledTokenNumber: nextWaiting?.token_number ?? null,
      };
    });

    const { previousTokenNumber, calledTokenNumber } = tx();
    this.markTwoAwaySmsAlerts(doctorId, shift);

    this.audit.record({
      event: 'DOCTOR_CALLED_NEXT',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId,
      tokenNumber: calledTokenNumber,
      details: { shift, previousTokenNumber, calledTokenNumber },
    });

    this.notifyChange(doctorId, shift);
    const board = this.getDoctorQueueBoard(doctorId, shift);
    return { calledToken: board.activeToken, board };
  }

  markConsultationCompleted(
    doctorId: number,
    shift: ShiftType,
    durationMinutes: number,
    actor: AuthUser
  ): DoctorQueueBoard {
    this.assertDoctorOwnership(actor, doctorId);
    const doctor = this.getDoctorById(doctorId);
    const clampedDuration = clampConsultationDuration(durationMinutes);

    const tx = this.db.transaction(() => {
      const now = new Date();
      const nowIso = now.toISOString();

      const currentActive = this.db
        .prepare(`
          SELECT id, token_number
          FROM queue_tokens
          WHERE doctor_id = ? AND shift = ? AND status = 'in_consultation'
          LIMIT 1
        `)
        .get(doctorId, shift) as { id: number; token_number: number } | undefined;

      if (!currentActive) {
        throw new ValidationError('No active consultation in progress to mark completed');
      }

      this.db
        .prepare(`
          UPDATE queue_tokens
          SET status = 'completed', completed_at = ?, consultation_duration = ?
          WHERE id = ?
        `)
        .run(nowIso, clampedDuration, currentActive.id);

      const updatedDurations = [...doctor.recentDurations, clampedDuration].slice(-5);
      const newEwma = calculateEwma(updatedDurations, doctor.baseAvgMinutes);

      this.db
        .prepare(`
          UPDATE doctors
          SET recent_durations_json = ?, ewma_minutes = ?
          WHERE id = ?
        `)
        .run(JSON.stringify(updatedDurations), newEwma, doctorId);

      const dayIndex = (now.getDay() + 6) % 7;
      const hourNum = shift === 'morning' ? 11 : 17;
      this.db
        .prepare(`
          INSERT INTO wait_time_history (clinic_id, day_index, hour_num, avg_wait_minutes, sample_count)
          VALUES (?, ?, ?, ?, 1)
        `)
        .run(doctor.clinicId, dayIndex, hourNum, clampedDuration);

      const nextWaiting = this.db
        .prepare(`
          SELECT id, token_number
          FROM queue_tokens
          WHERE doctor_id = ? AND shift = ? AND status = 'waiting'
          ORDER BY is_emergency DESC, priority_rank ASC, token_number ASC
          LIMIT 1
        `)
        .get(doctorId, shift) as { id: number; token_number: number } | undefined;

      if (nextWaiting) {
        this.db
          .prepare(`
            UPDATE queue_tokens
            SET status = 'in_consultation', called_at = ?, checked_in = 1, checked_in_at = COALESCE(checked_in_at, ?)
            WHERE id = ?
          `)
          .run(nowIso, nowIso, nextWaiting.id);
      }

      return {
        completedTokenNumber: currentActive.token_number,
        nextTokenNumber: nextWaiting?.token_number ?? null,
        newEwma,
      };
    });

    const result = tx();
    this.markTwoAwaySmsAlerts(doctorId, shift);

    this.audit.record({
      event: 'CONSULTATION_COMPLETED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId,
      tokenNumber: result.completedTokenNumber,
      details: {
        shift,
        recordedDurationMinutes: clampedDuration,
        updatedEwmaMinutes: result.newEwma,
        advancedToTokenNumber: result.nextTokenNumber,
      },
    });

    this.notifyChange(doctorId, shift);
    return this.getDoctorQueueBoard(doctorId, shift);
  }

  delayDoctor(
    doctorId: number,
    shift: ShiftType,
    delayMinutes: number,
    actor: AuthUser
  ): DoctorQueueBoard {
    this.assertDoctorOwnership(actor, doctorId);
    this.getDoctorById(doctorId);

    const statusCol = shift === 'morning' ? 'morning_status' : 'evening_status';
    const delayCol = shift === 'morning' ? 'morning_delay_minutes' : 'evening_delay_minutes';

    this.db
      .prepare(`
        UPDATE doctors
        SET ${statusCol} = 'Delayed',
            ${delayCol} = ${delayCol} + ?
        WHERE id = ?
      `)
      .run(delayMinutes, doctorId);

    this.audit.record({
      event: 'DOCTOR_DELAYED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId,
      details: { shift, addedDelayMinutes: delayMinutes },
    });

    this.notifyChange(doctorId, shift);
    return this.getDoctorQueueBoard(doctorId, shift);
  }

  updateDoctorStatus(
    doctorId: number,
    shift: ShiftType,
    status: DoctorStatusType,
    actor: AuthUser,
    resetDelay = false
  ): DoctorQueueBoard {
    this.assertDoctorOwnership(actor, doctorId);
    this.getDoctorById(doctorId);

    const statusCol = shift === 'morning' ? 'morning_status' : 'evening_status';
    const delayCol = shift === 'morning' ? 'morning_delay_minutes' : 'evening_delay_minutes';

    if (resetDelay) {
      this.db
        .prepare(`UPDATE doctors SET ${statusCol} = ?, ${delayCol} = 0 WHERE id = ?`)
        .run(status, doctorId);
    } else {
      this.db
        .prepare(`UPDATE doctors SET ${statusCol} = ? WHERE id = ?`)
        .run(status, doctorId);
    }

    this.audit.record({
      event: 'DOCTOR_STATUS_UPDATED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId,
      details: { shift, status, resetDelay },
    });

    this.notifyChange(doctorId, shift);
    return this.getDoctorQueueBoard(doctorId, shift);
  }

  skipAbsentToken(
    doctorId: number,
    shift: ShiftType,
    actor: AuthUser,
    targetTokenId?: number
  ): DoctorQueueBoard {
    this.assertDoctorOwnership(actor, doctorId);
    this.getDoctorById(doctorId);

    const tx = this.db.transaction(() => {
      const nowIso = new Date().toISOString();
      let tokenToSkip: { id: number; token_number: number; status: TokenStatusType } | undefined;

      if (targetTokenId) {
        tokenToSkip = this.db
          .prepare(`
            SELECT id, token_number, status
            FROM queue_tokens
            WHERE id = ? AND doctor_id = ? AND shift = ? AND status IN ('in_consultation', 'waiting')
          `)
          .get(targetTokenId, doctorId, shift) as
          | { id: number; token_number: number; status: TokenStatusType }
          | undefined;
      } else {
        tokenToSkip = this.db
          .prepare(`
            SELECT id, token_number, status
            FROM queue_tokens
            WHERE doctor_id = ? AND shift = ? AND status = 'in_consultation'
            LIMIT 1
          `)
          .get(doctorId, shift) as
          | { id: number; token_number: number; status: TokenStatusType }
          | undefined;

        if (!tokenToSkip) {
          tokenToSkip = this.db
            .prepare(`
              SELECT id, token_number, status
              FROM queue_tokens
              WHERE doctor_id = ? AND shift = ? AND status = 'waiting'
              ORDER BY is_emergency DESC, priority_rank ASC, token_number ASC
              LIMIT 1
            `)
            .get(doctorId, shift) as
            | { id: number; token_number: number; status: TokenStatusType }
            | undefined;
        }
      }

      if (!tokenToSkip) {
        throw new ValidationError('No active or waiting token available to mark absent');
      }

      this.db
        .prepare("UPDATE queue_tokens SET status = 'holding' WHERE id = ?")
        .run(tokenToSkip.id);

      let calledNextNumber: number | null = null;
      const hasActive = this.db
        .prepare(
          "SELECT id FROM queue_tokens WHERE doctor_id = ? AND shift = ? AND status = 'in_consultation' LIMIT 1"
        )
        .get(doctorId, shift);

      if (!hasActive) {
        const nextWaiting = this.db
          .prepare(`
            SELECT id, token_number
            FROM queue_tokens
            WHERE doctor_id = ? AND shift = ? AND status = 'waiting'
            ORDER BY is_emergency DESC, priority_rank ASC, token_number ASC
            LIMIT 1
          `)
          .get(doctorId, shift) as { id: number; token_number: number } | undefined;

        if (nextWaiting) {
          this.db
            .prepare(`
              UPDATE queue_tokens
              SET status = 'in_consultation', called_at = ?, checked_in = 1, checked_in_at = COALESCE(checked_in_at, ?)
              WHERE id = ?
            `)
            .run(nowIso, nowIso, nextWaiting.id);
          calledNextNumber = nextWaiting.token_number;
        }
      }

      return { skippedTokenNumber: tokenToSkip.token_number, calledNextNumber };
    });

    const res = tx();
    this.markTwoAwaySmsAlerts(doctorId, shift);

    this.audit.record({
      event: 'PATIENT_ABSENT_SKIPPED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId,
      tokenNumber: res.skippedTokenNumber,
      details: {
        shift,
        skippedTokenNumber: res.skippedTokenNumber,
        advancedToTokenNumber: res.calledNextNumber,
      },
    });

    this.notifyChange(doctorId, shift);
    return this.getDoctorQueueBoard(doctorId, shift);
  }

  recallHoldingToken(tokenId: number, actor: AuthUser): DoctorQueueBoard {
    const token = this.db
      .prepare('SELECT id, doctor_id, shift, token_number, status FROM queue_tokens WHERE id = ?')
      .get(tokenId) as
      | { id: number; doctor_id: number; shift: ShiftType; token_number: number; status: TokenStatusType }
      | undefined;

    if (!token) {
      throw new NotFoundError(`Queue token #${tokenId} not found`);
    }
    this.assertDoctorOwnership(actor, token.doctor_id);

    if (token.status !== 'holding') {
      throw new ValidationError('Only tokens in the absent holding queue can be recalled');
    }

    this.db
      .prepare("UPDATE queue_tokens SET status = 'waiting', priority_rank = 50 WHERE id = ?")
      .run(tokenId);

    this.audit.record({
      event: 'HOLDING_TOKEN_RECALLED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId: token.doctor_id,
      tokenNumber: token.token_number,
      details: { shift: token.shift },
    });

    this.notifyChange(token.doctor_id, token.shift);
    return this.getDoctorQueueBoard(token.doctor_id, token.shift);
  }

  escalateEmergencyPatient(
    input: {
      clinicId: number;
      doctorId: number;
      shift: ShiftType;
      patientName: string;
      patientPhone: string;
      symptoms: string;
    },
    actor: AuthUser
  ): { appointment: PatientAppointmentDetail; board: DoctorQueueBoard } {
    const doctor = this.getDoctorById(input.doctorId);
    if (doctor.clinicId !== input.clinicId) {
      throw new ValidationError('Selected doctor does not belong to the chosen clinic');
    }

    const tx = this.db.transaction(() => {
      const existingNumbers = (
        this.db
          .prepare(
            'SELECT token_number FROM queue_tokens WHERE clinic_id = ? AND doctor_id = ? AND shift = ?'
          )
          .all(input.clinicId, input.doctorId, input.shift) as Array<{ token_number: number }>
      ).map((r) => r.token_number);

      const nextTokenNumber = generateNextTokenNumber(existingNumbers);

      const maxEmergencyRankRow = this.db
        .prepare(`
          SELECT MAX(priority_rank) AS max_rank
          FROM queue_tokens
          WHERE doctor_id = ? AND shift = ? AND is_emergency = 1 AND status = 'waiting'
        `)
        .get(input.doctorId, input.shift) as { max_rank: number | null };

      const emergencyPriorityRank = (maxEmergencyRankRow.max_rank ?? 0) + 1;
      const now = new Date().toISOString();

      const apptRes = this.db
        .prepare(`
          INSERT INTO appointments (clinic_id, doctor_id, shift, patient_name, patient_phone, symptoms, booked_at)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          input.clinicId,
          input.doctorId,
          input.shift,
          input.patientName.trim(),
          input.patientPhone.trim(),
          input.symptoms.trim(),
          now
        );

      const appointmentId = Number(apptRes.lastInsertRowid);

      this.db
        .prepare(`
          INSERT INTO queue_tokens (
            appointment_id, clinic_id, doctor_id, shift, token_number, status,
            is_emergency, priority_rank, checked_in, checked_in_at, sms_alert_sent, created_at
          ) VALUES (?, ?, ?, ?, ?, 'waiting', 1, ?, 1, ?, 0, ?)
        `)
        .run(
          appointmentId,
          input.clinicId,
          input.doctorId,
          input.shift,
          nextTokenNumber,
          emergencyPriorityRank,
          now,
          now
        );

      return { appointmentId, nextTokenNumber, emergencyPriorityRank };
    });

    const { appointmentId, nextTokenNumber, emergencyPriorityRank } = tx();
    this.markTwoAwaySmsAlerts(input.doctorId, input.shift);

    this.audit.record({
      event: 'EMERGENCY_ESCALATED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId: input.doctorId,
      tokenNumber: nextTokenNumber,
      details: {
        shift: input.shift,
        appointmentId,
        patientName: input.patientName,
        priorityRank: emergencyPriorityRank,
      },
    });

    this.notifyChange(input.doctorId, input.shift);
    return {
      appointment: this.getAppointmentDetail(appointmentId),
      board: this.getDoctorQueueBoard(input.doctorId, input.shift),
    };
  }

  checkInWithGeolocation(
    appointmentId: number,
    latitude: number,
    longitude: number
  ): {
    checkedIn: boolean;
    distanceMeters: number;
    maxRadiusMeters: number;
    appointment: PatientAppointmentDetail;
  } {
    const appointment = this.getAppointmentDetail(appointmentId);
    const { withinRadius, distanceMeters } = isWithinCheckInRadius(
      latitude,
      longitude,
      appointment.clinic.latitude,
      appointment.clinic.longitude,
      CLINIC_CHECKIN_RADIUS_METERS
    );

    if (!withinRadius) {
      throw new ValidationError(
        `You are ${distanceMeters}m away from ${appointment.clinic.name}. Move within ${CLINIC_CHECKIN_RADIUS_METERS}m to activate virtual check-in.`,
        { distanceMeters, maxRadiusMeters: CLINIC_CHECKIN_RADIUS_METERS }
      );
    }

    const nowIso = new Date().toISOString();
    this.db
      .prepare('UPDATE queue_tokens SET checked_in = 1, checked_in_at = COALESCE(checked_in_at, ?) WHERE appointment_id = ?')
      .run(nowIso, appointmentId);

    this.audit.record({
      event: 'GEOLOCATION_CHECKIN',
      actorRole: 'patient',
      actorName: appointment.patientName,
      doctorId: appointment.doctor.id,
      tokenNumber: appointment.tokenNumber,
      details: { appointmentId, distanceMeters, clinicId: appointment.clinic.id },
    });

    this.notifyChange(appointment.doctor.id, appointment.shift);
    return {
      checkedIn: true,
      distanceMeters,
      maxRadiusMeters: CLINIC_CHECKIN_RADIUS_METERS,
      appointment: this.getAppointmentDetail(appointmentId),
    };
  }

  attachPrescription(
    appointmentId: number,
    fileMeta: { fileName: string; storedPath: string; mimeType: string; fileSize: number },
    notes: string,
    actor: AuthUser
  ): PrescriptionAttachment {
    const appointment = this.getAppointmentDetail(appointmentId);
    this.assertDoctorOwnership(actor, appointment.doctor.id);

    const nowIso = new Date().toISOString();
    const existing = this.db
      .prepare('SELECT id FROM prescriptions WHERE appointment_id = ?')
      .get(appointmentId) as { id: number } | undefined;

    if (existing) {
      this.db
        .prepare(`
          UPDATE prescriptions
          SET file_name = ?, stored_path = ?, mime_type = ?, file_size = ?, notes = ?, uploaded_at = ?
          WHERE appointment_id = ?
        `)
        .run(
          fileMeta.fileName,
          fileMeta.storedPath,
          fileMeta.mimeType,
          fileMeta.fileSize,
          notes,
          nowIso,
          appointmentId
        );
    } else {
      this.db
        .prepare(`
          INSERT INTO prescriptions (appointment_id, doctor_id, file_name, stored_path, mime_type, file_size, notes, uploaded_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `)
        .run(
          appointmentId,
          appointment.doctor.id,
          fileMeta.fileName,
          fileMeta.storedPath,
          fileMeta.mimeType,
          fileMeta.fileSize,
          notes,
          nowIso
        );
    }

    this.audit.record({
      event: 'PRESCRIPTION_ATTACHED',
      actorRole: actor.role,
      actorName: actor.name,
      doctorId: appointment.doctor.id,
      tokenNumber: appointment.tokenNumber,
      details: { appointmentId, fileName: fileMeta.fileName, fileSize: fileMeta.fileSize },
    });

    const saved = this.db
      .prepare(
        'SELECT id, appointment_id, doctor_id, file_name, mime_type, file_size, notes, uploaded_at FROM prescriptions WHERE appointment_id = ?'
      )
      .get(appointmentId) as {
      id: number;
      appointment_id: number;
      doctor_id: number;
      file_name: string;
      mime_type: string;
      file_size: number;
      notes: string;
      uploaded_at: string;
    };

    this.notifyChange(appointment.doctor.id, appointment.shift);

    return {
      id: saved.id,
      appointmentId: saved.appointment_id,
      doctorId: saved.doctor_id,
      fileName: saved.file_name,
      mimeType: saved.mime_type,
      fileSize: saved.file_size,
      notes: saved.notes,
      uploadedAt: saved.uploaded_at,
    };
  }

  getPrescriptionDownloadMeta(appointmentId: number): {
    fileName: string;
    storedPath: string;
    mimeType: string;
  } {
    const row = this.db
      .prepare('SELECT file_name, stored_path, mime_type FROM prescriptions WHERE appointment_id = ?')
      .get(appointmentId) as
      | { file_name: string; stored_path: string; mime_type: string }
      | undefined;
    if (!row) {
      throw new NotFoundError(`No prescription attachment found for appointment #${appointmentId}`);
    }
    return {
      fileName: row.file_name,
      storedPath: row.stored_path,
      mimeType: row.mime_type,
    };
  }

  getPaginatedTokenHistory(params: {
    page: number;
    limit: number;
    clinicId?: number;
    doctorId?: number;
    status?: string;
  }): PaginatedTokenHistory {
    const page = Math.max(1, params.page);
    const limit = Math.min(50, Math.max(1, params.limit));
    const offset = (page - 1) * limit;

    const conditions: string[] = [];
    const bind: Record<string, unknown> = {};

    if (params.clinicId) {
      conditions.push('qt.clinic_id = @clinicId');
      bind.clinicId = params.clinicId;
    }
    if (params.doctorId) {
      conditions.push('qt.doctor_id = @doctorId');
      bind.doctorId = params.doctorId;
    }
    if (params.status && params.status !== 'all') {
      conditions.push('qt.status = @status');
      bind.status = params.status;
    }

    const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const countRow = this.db
      .prepare(`SELECT COUNT(*) AS total FROM queue_tokens qt ${where}`)
      .get(bind) as { total: number };

    const rows = this.db
      .prepare(`
        SELECT
          qt.*,
          a.patient_name,
          a.patient_phone,
          d.name AS doctor_name,
          s.name AS specialty_name,
          c.name AS clinic_name
        FROM queue_tokens qt
        JOIN appointments a ON a.id = qt.appointment_id
        JOIN doctors d ON d.id = qt.doctor_id
        JOIN specialties s ON s.id = d.specialty_id
        JOIN clinics c ON c.id = qt.clinic_id
        ${where}
        ORDER BY qt.created_at DESC, qt.id DESC
        LIMIT @limit OFFSET @offset
      `)
      .all({ ...bind, limit, offset }) as Array<
      TokenRow & { doctor_name: string; specialty_name: string; clinic_name: string }
    >;

    return {
      items: rows.map((row) => ({
        ...mapTokenRow(row),
        doctorName: row.doctor_name,
        specialtyName: row.specialty_name,
        clinicName: row.clinic_name,
      })),
      page,
      limit,
      total: countRow.total,
      totalPages: Math.max(1, Math.ceil(countRow.total / limit)),
    };
  }

  getClinicHeatmapData(clinicId?: number): HeatmapCell[] {
    const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const hourSlots = [9, 10, 11, 12, 16, 17, 18];

    const where = clinicId ? 'WHERE clinic_id = @clinicId' : '';
    const rows = this.db
      .prepare(`
        SELECT
          day_index,
          hour_num,
          ROUND(SUM(avg_wait_minutes * sample_count) / SUM(sample_count), 1) AS avg_wait,
          SUM(sample_count) AS total_samples
        FROM wait_time_history
        ${where}
        GROUP BY day_index, hour_num
      `)
      .all(clinicId ? { clinicId } : {}) as Array<{
      day_index: number;
      hour_num: number;
      avg_wait: number;
      total_samples: number;
    }>;

    const map = new Map<string, { avgWait: number; sampleCount: number }>();
    for (const r of rows) {
      map.set(`${r.day_index}-${r.hour_num}`, {
        avgWait: r.avg_wait,
        sampleCount: r.total_samples,
      });
    }

    const cells: HeatmapCell[] = [];
    for (let dayIndex = 0; dayIndex < 7; dayIndex += 1) {
      for (const hourNum of hourSlots) {
        const found = map.get(`${dayIndex}-${hourNum}`);
        const label =
          hourNum < 12 ? `${hourNum}:00 AM` : hourNum === 12 ? '12:00 PM' : `${hourNum - 12}:00 PM`;
        cells.push({
          dayOfWeek: dayNames[dayIndex],
          dayIndex,
          hourSlot: label,
          hourNum,
          avgWaitMinutes: found?.avgWait ?? 0,
          sampleCount: found?.sampleCount ?? 0,
        });
      }
    }
    return cells;
  }

  getAuditLogs(limit = 40): AuditLogEntry[] {
    const rows = this.db
      .prepare(`
        SELECT id, event, actor_role, actor_name, doctor_id, token_number, details, created_at
        FROM audit_logs
        ORDER BY id DESC
        LIMIT ?
      `)
      .all(Math.min(100, Math.max(1, limit))) as Array<{
      id: number;
      event: string;
      actor_role: string;
      actor_name: string;
      doctor_id: number | null;
      token_number: number | null;
      details: string;
      created_at: string;
    }>;

    return rows.map((r) => ({
      id: r.id,
      event: r.event,
      actorRole: r.actor_role,
      actorName: r.actor_name,
      doctorId: r.doctor_id,
      tokenNumber: r.token_number,
      details: r.details,
      createdAt: r.created_at,
    }));
  }
}
