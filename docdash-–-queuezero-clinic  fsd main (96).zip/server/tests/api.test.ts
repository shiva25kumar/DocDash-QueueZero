import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp, type AppInstance } from '../app.ts';

class CookieJar {
  private cookies = new Map<string, string>();

  updateFromResponse(res: Response): void {
    const setCookies = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    for (const raw of setCookies) {
      const [pair] = raw.split(';');
      const eq = pair.indexOf('=');
      if (eq > 0) {
        const name = pair.slice(0, eq).trim();
        const val = pair.slice(eq + 1).trim();
        this.cookies.set(name, val);
      }
    }
  }

  get(name: string): string | undefined {
    return this.cookies.get(name);
  }

  header(): string {
    return Array.from(this.cookies.entries())
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
  }
}

async function startTestApp(bookingRateLimitMax = 50): Promise<{
  instance: AppInstance;
  baseUrl: string;
  cleanup: () => Promise<void>;
}> {
  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'docdash-test-'));
  const instance = createApp({
    dbPath: ':memory:',
    uploadDir: path.join(tmpDir, 'uploads'),
    bookingRateLimitMax,
  });

  await new Promise<void>((resolve) => {
    instance.server.listen(0, '127.0.0.1', () => resolve());
  });
  const addr = instance.server.address();
  if (!addr || typeof addr === 'string') {
    throw new Error('Failed to bind ephemeral port');
  }
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  return {
    instance,
    baseUrl,
    cleanup: async () => {
      await instance.close();
      fs.rmSync(tmpDir, { recursive: true, force: true });
    },
  };
}

async function getCsrf(baseUrl: string, jar: CookieJar): Promise<string> {
  const res = await fetch(`${baseUrl}/api/auth/csrf`, {
    headers: { Cookie: jar.header() },
  });
  jar.updateFromResponse(res);
  const body = (await res.json()) as { csrfToken: string };
  return body.csrfToken;
}

async function login(
  baseUrl: string,
  jar: CookieJar,
  email: string,
  password: string
): Promise<{ csrfToken: string; role: string }> {
  const res = await fetch(`${baseUrl}/api/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Cookie: jar.header() },
    body: JSON.stringify({ email, password }),
  });
  jar.updateFromResponse(res);
  assert.equal(res.status, 200);
  const body = (await res.json()) as { csrfToken: string; user: { role: string } };
  return { csrfToken: body.csrfToken, role: body.user.role };
}

test('doctor directory returns 4 clinics, 4 specialties, 8 doctors, and 20 seeded tokens', async () => {
  const { baseUrl, cleanup } = await startTestApp();
  try {
    const clinicsRes = await fetch(`${baseUrl}/api/clinics`);
    const clinicsJson = (await clinicsRes.json()) as { clinics: unknown[] };
    assert.equal(clinicsJson.clinics.length, 4);

    const specRes = await fetch(`${baseUrl}/api/specialties`);
    const specJson = (await specRes.json()) as { specialties: Array<{ name: string }> };
    assert.deepEqual(
      specJson.specialties.map((s) => s.name),
      ['General Medicine', 'Pediatrics', 'Orthopedics', 'Cardiology']
    );

    const docsRes = await fetch(`${baseUrl}/api/doctors?specialty=Cardiology`);
    const docsJson = (await docsRes.json()) as { doctors: Array<{ name: string }> };
    assert.equal(docsJson.doctors.length, 2);
    assert.equal(docsJson.doctors[0].name, 'Dr. Arjun Mehta');

    const historyRes = await fetch(`${baseUrl}/api/queue/history?page=1&limit=10`);
    const historyJson = (await historyRes.json()) as {
      history: { total: number; totalPages: number; items: unknown[] };
    };
    assert.equal(historyJson.history.total, 20);
    assert.equal(historyJson.history.totalPages, 2);
    assert.equal(historyJson.history.items.length, 10);
  } finally {
    await cleanup();
  }
});

test('Patient A booking and Doctor Mehta Call Next Patient reproduces exact 36m -> 24m + SMS alert demo', async () => {
  const { baseUrl, cleanup } = await startTestApp();
  try {
    const patientJar = new CookieJar();
    const patientCsrf = await getCsrf(baseUrl, patientJar);

    // 1. Patient A books Token #14 with Dr. Mehta (Cardiology, Morning Shift)
    const bookRes = await fetch(`${baseUrl}/api/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: patientJar.header(),
        'X-CSRF-Token': patientCsrf,
      },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Patient A',
        patientPhone: '555-9914',
        symptoms: 'Routine cardiac follow-up',
      }),
    });
    assert.equal(bookRes.status, 201);
    const bookJson = (await bookRes.json()) as {
      appointment: {
        appointmentId: number;
        tokenNumber: number;
        currentlyServingTokenNumber: number;
        patientsAhead: number;
        estimatedWaitMinutes: number;
        shouldTriggerSmsAlert: boolean;
      };
    };

    assert.equal(bookJson.appointment.tokenNumber, 14);
    assert.equal(bookJson.appointment.currentlyServingTokenNumber, 11);
    assert.equal(bookJson.appointment.patientsAhead, 3);
    assert.equal(bookJson.appointment.estimatedWaitMinutes, 36);
    assert.equal(bookJson.appointment.shouldTriggerSmsAlert, false);

    // 2. Doctor Mehta authenticates and clicks Call Next Patient -> Token #12
    const docJar = new CookieJar();
    const { csrfToken: docCsrf } = await login(
      baseUrl,
      docJar,
      'dr.mehta@queuezero.clinic',
      'Doctor@123'
    );

    const nextRes = await fetch(`${baseUrl}/api/console/call-next`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: docJar.header(),
        'X-CSRF-Token': docCsrf,
      },
      body: JSON.stringify({ doctorId: 1, shift: 'morning' }),
    });
    assert.equal(nextRes.status, 200);
    const nextJson = (await nextRes.json()) as {
      calledToken: { tokenNumber: number };
    };
    assert.equal(nextJson.calledToken.tokenNumber, 12);

    // 3. Patient dashboard fetches updated appointment
    const apptRes = await fetch(
      `${baseUrl}/api/appointments/${bookJson.appointment.appointmentId}`
    );
    assert.equal(apptRes.status, 200);
    const apptJson = (await apptRes.json()) as {
      appointment: {
        tokenNumber: number;
        currentlyServingTokenNumber: number;
        patientsAhead: number;
        estimatedWaitMinutes: number;
        shouldTriggerSmsAlert: boolean;
      };
    };

    assert.equal(apptJson.appointment.tokenNumber, 14);
    assert.equal(apptJson.appointment.currentlyServingTokenNumber, 12);
    assert.equal(apptJson.appointment.patientsAhead, 2);
    assert.equal(apptJson.appointment.estimatedWaitMinutes, 24);
    assert.equal(apptJson.appointment.shouldTriggerSmsAlert, true);
  } finally {
    await cleanup();
  }
});

test('doctor delay, mark-completed EWMA update, absent-skip, geolocation check-in, and emergency triage work end-to-end', async () => {
  const { baseUrl, cleanup } = await startTestApp();
  try {
    const docJar = new CookieJar();
    const { csrfToken: docCsrf } = await login(
      baseUrl,
      docJar,
      'dr.mehta@queuezero.clinic',
      'Doctor@123'
    );

    // Delay 10 mins
    const delayRes = await fetch(`${baseUrl}/api/console/delay`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: docJar.header(),
        'X-CSRF-Token': docCsrf,
      },
      body: JSON.stringify({ doctorId: 1, shift: 'morning', delayMinutes: 10 }),
    });
    assert.equal(delayRes.status, 200);
    const delayJson = (await delayRes.json()) as {
      board: { doctorStatus: string; offsetDelayMinutes: number };
    };
    assert.equal(delayJson.board.doctorStatus, 'Delayed');
    assert.equal(delayJson.board.offsetDelayMinutes, 10);

    // Mark Completed with 20 mins consultation duration -> EWMA increases above 12
    const completeRes = await fetch(`${baseUrl}/api/console/complete`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: docJar.header(),
        'X-CSRF-Token': docCsrf,
      },
      body: JSON.stringify({ doctorId: 1, shift: 'morning', durationMinutes: 20 }),
    });
    assert.equal(completeRes.status, 200);
    const completeJson = (await completeRes.json()) as {
      board: { ewmaMinutes: number; activeToken: { tokenNumber: number } };
    };
    assert.ok(completeJson.board.ewmaMinutes > 12);
    assert.equal(completeJson.board.activeToken.tokenNumber, 12);

    // Skip absent token (#12) -> moves to holding and advances to #13
    const skipRes = await fetch(`${baseUrl}/api/console/skip-absent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: docJar.header(),
        'X-CSRF-Token': docCsrf,
      },
      body: JSON.stringify({ doctorId: 1, shift: 'morning' }),
    });
    assert.equal(skipRes.status, 200);
    const skipJson = (await skipRes.json()) as {
      board: {
        activeToken: { tokenNumber: number };
        holdingTokens: Array<{ tokenNumber: number }>;
      };
    };
    assert.equal(skipJson.board.activeToken.tokenNumber, 13);
    assert.equal(skipJson.board.holdingTokens.length, 1);
    assert.equal(skipJson.board.holdingTokens[0].tokenNumber, 12);

    // Triage staff escalates an emergency patient
    const triageJar = new CookieJar();
    const { csrfToken: triageCsrf } = await login(
      baseUrl,
      triageJar,
      'triage@queuezero.clinic',
      'Triage@123'
    );

    const emergencyRes = await fetch(`${baseUrl}/api/triage/emergency`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: triageJar.header(),
        'X-CSRF-Token': triageCsrf,
      },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Urgent Trauma Case',
        patientPhone: '555-9110',
        symptoms: 'Acute chest tightness',
      }),
    });
    assert.equal(emergencyRes.status, 201);
    const emergencyJson = (await emergencyRes.json()) as {
      appointment: { appointmentId: number; isEmergency: boolean; queuePosition: number };
      board: { nextToken: { isEmergency: boolean; patientName: string } };
    };
    assert.equal(emergencyJson.appointment.isEmergency, true);
    assert.equal(emergencyJson.board.nextToken.isEmergency, true);
    assert.equal(emergencyJson.board.nextToken.patientName, 'Urgent Trauma Case');

    // Geolocation check-in within 500m of Downtown Medical Center (37.7749, -122.4194)
    const checkinRes = await fetch(
      `${baseUrl}/api/appointments/${emergencyJson.appointment.appointmentId}/checkin`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Cookie: triageJar.header(),
          'X-CSRF-Token': triageCsrf,
        },
        body: JSON.stringify({ latitude: 37.7755, longitude: -122.4194 }),
      }
    );
    assert.equal(checkinRes.status, 200);
    const checkinJson = (await checkinRes.json()) as {
      checkedIn: boolean;
      distanceMeters: number;
    };
    assert.equal(checkinJson.checkedIn, true);
    assert.ok(checkinJson.distanceMeters <= 500);
  } finally {
    await cleanup();
  }
});

test('RBAC, CSRF protection, and booking rate limiting enforce security policies', async () => {
  const { baseUrl, cleanup } = await startTestApp(2);
  try {
    const anonJar = new CookieJar();
    const csrf = await getCsrf(baseUrl, anonJar);

    // Unauthenticated doctor console action => 401
    const unauthRes = await fetch(`${baseUrl}/api/console/call-next`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: anonJar.header(),
        'X-CSRF-Token': csrf,
      },
      body: JSON.stringify({ doctorId: 1, shift: 'morning' }),
    });
    assert.equal(unauthRes.status, 401);

    // Patient role cannot execute doctor or triage actions => 403
    const patientJar = new CookieJar();
    const { csrfToken: patientCsrf } = await login(
      baseUrl,
      patientJar,
      'patient@queuezero.clinic',
      'Patient@123'
    );

    const forbiddenDocRes = await fetch(`${baseUrl}/api/console/call-next`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: patientJar.header(),
        'X-CSRF-Token': patientCsrf,
      },
      body: JSON.stringify({ doctorId: 1, shift: 'morning' }),
    });
    assert.equal(forbiddenDocRes.status, 403);

    const forbiddenTriageRes = await fetch(`${baseUrl}/api/triage/emergency`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: patientJar.header(),
        'X-CSRF-Token': patientCsrf,
      },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Test',
        patientPhone: '555-0001',
        symptoms: 'Pain',
      }),
    });
    assert.equal(forbiddenTriageRes.status, 403);

    // Missing CSRF header => 403
    const missingCsrfRes = await fetch(`${baseUrl}/api/appointments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Cookie: patientJar.header() },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Test No Csrf',
        patientPhone: '555-3301',
      }),
    });
    assert.equal(missingCsrfRes.status, 403);

    // Rate limiting on /api/appointments (max 2 per window in this test)
    const book1 = await fetch(`${baseUrl}/api/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: patientJar.header(),
        'X-CSRF-Token': patientCsrf,
      },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Rate User 1',
        patientPhone: '555-4401',
      }),
    });
    assert.equal(book1.status, 201);

    const book2 = await fetch(`${baseUrl}/api/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: patientJar.header(),
        'X-CSRF-Token': patientCsrf,
      },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Rate User 2',
        patientPhone: '555-4402',
      }),
    });
    assert.equal(book2.status, 201);

    const book3 = await fetch(`${baseUrl}/api/appointments`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Cookie: patientJar.header(),
        'X-CSRF-Token': patientCsrf,
      },
      body: JSON.stringify({
        clinicId: 1,
        doctorId: 1,
        shift: 'morning',
        patientName: 'Rate User 3',
        patientPhone: '555-4403',
      }),
    });
    assert.equal(book3.status, 429);
  } finally {
    await cleanup();
  }
});
