import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import { calculateEwma } from '../../src/utils/queueEstimator.ts';

interface SeedClinic {
  id: number;
  name: string;
  code: string;
  address: string;
  neighborhood: string;
  phone: string;
  latitude: number;
  longitude: number;
}

interface SeedSpecialty {
  id: number;
  name: string;
  description: string;
}

interface SeedDoctor {
  id: number;
  clinicId: number;
  specialtyId: number;
  name: string;
  credentials: string;
  roomNumber: string;
  consultationFee: number;
  baseAvgMinutes: number;
  recentDurations: number[];
  morningStatus: string;
  eveningStatus: string;
  morningDelayMinutes: number;
  eveningDelayMinutes: number;
}

interface SeedToken {
  doctorId: number;
  clinicId: number;
  shift: string;
  tokenNumber: number;
  status: string;
  patientName: string;
  patientPhone: string;
  duration: number | null;
  hourSlot: string;
  dayIndex: number;
}

interface SeedWaitLog {
  clinicId: number;
  dayIndex: number;
  hourNum: number;
  avgWaitMinutes: number;
  sampleCount: number;
}

interface SeedPayload {
  clinics: SeedClinic[];
  specialties: SeedSpecialty[];
  doctors: SeedDoctor[];
  sampleTokens: SeedToken[];
  historicalWaitLogs: SeedWaitLog[];
}

export function initializeDatabase(dbPath: string): Database.Database {
  if (dbPath !== ':memory:') {
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }

  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS clinics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      code TEXT NOT NULL UNIQUE,
      address TEXT NOT NULL,
      neighborhood TEXT NOT NULL,
      phone TEXT NOT NULL,
      latitude REAL NOT NULL,
      longitude REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS specialties (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS doctors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clinic_id INTEGER NOT NULL REFERENCES clinics(id) ON DELETE CASCADE,
      specialty_id INTEGER NOT NULL REFERENCES specialties(id) ON DELETE RESTRICT,
      name TEXT NOT NULL,
      credentials TEXT NOT NULL,
      room_number TEXT NOT NULL,
      consultation_fee INTEGER NOT NULL,
      base_avg_minutes REAL NOT NULL,
      ewma_minutes REAL NOT NULL,
      recent_durations_json TEXT NOT NULL,
      morning_status TEXT NOT NULL DEFAULT 'In Consultation',
      evening_status TEXT NOT NULL DEFAULT 'In Consultation',
      morning_delay_minutes INTEGER NOT NULL DEFAULT 0,
      evening_delay_minutes INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('patient', 'doctor', 'triage_staff')),
      doctor_id INTEGER REFERENCES doctors(id) ON DELETE SET NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clinic_id INTEGER NOT NULL REFERENCES clinics(id) ON DELETE CASCADE,
      doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
      shift TEXT NOT NULL CHECK (shift IN ('morning', 'evening')),
      patient_name TEXT NOT NULL,
      patient_phone TEXT NOT NULL,
      symptoms TEXT NOT NULL DEFAULT '',
      booked_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS queue_tokens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
      clinic_id INTEGER NOT NULL REFERENCES clinics(id) ON DELETE CASCADE,
      doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
      shift TEXT NOT NULL CHECK (shift IN ('morning', 'evening')),
      token_number INTEGER NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('waiting', 'in_consultation', 'completed', 'holding', 'cancelled')),
      is_emergency INTEGER NOT NULL DEFAULT 0,
      priority_rank INTEGER NOT NULL DEFAULT 100,
      checked_in INTEGER NOT NULL DEFAULT 0,
      checked_in_at TEXT,
      called_at TEXT,
      completed_at TEXT,
      consultation_duration INTEGER,
      sms_alert_sent INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      UNIQUE(clinic_id, doctor_id, shift, token_number)
    );

    CREATE TABLE IF NOT EXISTS prescriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      appointment_id INTEGER NOT NULL UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
      doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
      file_name TEXT NOT NULL,
      stored_path TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      file_size INTEGER NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      uploaded_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wait_time_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      clinic_id INTEGER NOT NULL REFERENCES clinics(id) ON DELETE CASCADE,
      day_index INTEGER NOT NULL CHECK (day_index BETWEEN 0 AND 6),
      hour_num INTEGER NOT NULL CHECK (hour_num BETWEEN 0 AND 23),
      avg_wait_minutes REAL NOT NULL,
      sample_count INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      actor_name TEXT NOT NULL,
      doctor_id INTEGER,
      token_number INTEGER,
      details TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_doctors_clinic ON doctors(clinic_id);
    CREATE INDEX IF NOT EXISTS idx_doctors_specialty ON doctors(specialty_id);
    CREATE INDEX IF NOT EXISTS idx_appointments_phone ON appointments(patient_phone);
    CREATE INDEX IF NOT EXISTS idx_tokens_queue_lookup ON queue_tokens(doctor_id, clinic_id, shift, status, is_emergency, priority_rank, token_number);
    CREATE INDEX IF NOT EXISTS idx_tokens_history ON queue_tokens(created_at DESC, id DESC);
    CREATE INDEX IF NOT EXISTS idx_wait_history_clinic ON wait_time_history(clinic_id, day_index, hour_num);
    CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at DESC);
  `);

  seedIfEmpty(db);
  return db;
}

function seedIfEmpty(db: Database.Database): void {
  const clinicCount = (db.prepare('SELECT COUNT(*) as c FROM clinics').get() as { c: number }).c;
  if (clinicCount > 0) {
    return;
  }

  const seedPath = path.resolve(process.cwd(), 'server/db/seed.json');
  const seedRaw = fs.readFileSync(seedPath, 'utf-8');
  const seed = JSON.parse(seedRaw) as SeedPayload;

  const insertClinic = db.prepare(`
    INSERT INTO clinics (id, name, code, address, neighborhood, phone, latitude, longitude)
    VALUES (@id, @name, @code, @address, @neighborhood, @phone, @latitude, @longitude)
  `);

  const insertSpecialty = db.prepare(`
    INSERT INTO specialties (id, name, description)
    VALUES (@id, @name, @description)
  `);

  const insertDoctor = db.prepare(`
    INSERT INTO doctors (
      id, clinic_id, specialty_id, name, credentials, room_number, consultation_fee,
      base_avg_minutes, ewma_minutes, recent_durations_json,
      morning_status, evening_status, morning_delay_minutes, evening_delay_minutes
    ) VALUES (
      @id, @clinicId, @specialtyId, @name, @credentials, @roomNumber, @consultationFee,
      @baseAvgMinutes, @ewmaMinutes, @recentDurationsJson,
      @morningStatus, @eveningStatus, @morningDelayMinutes, @eveningDelayMinutes
    )
  `);

  const insertAppointment = db.prepare(`
    INSERT INTO appointments (clinic_id, doctor_id, shift, patient_name, patient_phone, symptoms, booked_at)
    VALUES (@clinicId, @doctorId, @shift, @patientName, @patientPhone, @symptoms, @bookedAt)
  `);

  const insertToken = db.prepare(`
    INSERT INTO queue_tokens (
      appointment_id, clinic_id, doctor_id, shift, token_number, status,
      is_emergency, priority_rank, checked_in, called_at, completed_at,
      consultation_duration, sms_alert_sent, created_at
    ) VALUES (
      @appointmentId, @clinicId, @doctorId, @shift, @tokenNumber, @status,
      0, 100, @checkedIn, @calledAt, @completedAt,
      @consultationDuration, 0, @createdAt
    )
  `);

  const insertWaitLog = db.prepare(`
    INSERT INTO wait_time_history (clinic_id, day_index, hour_num, avg_wait_minutes, sample_count)
    VALUES (@clinicId, @dayIndex, @hourNum, @avgWaitMinutes, @sampleCount)
  `);

  const insertUser = db.prepare(`
    INSERT INTO users (email, password_hash, name, role, doctor_id, created_at)
    VALUES (@email, @passwordHash, @name, @role, @doctorId, @createdAt)
  `);

  const runSeed = db.transaction(() => {
    for (const c of seed.clinics) {
      insertClinic.run(c);
    }
    for (const s of seed.specialties) {
      insertSpecialty.run(s);
    }
    for (const d of seed.doctors) {
      const ewma = calculateEwma(d.recentDurations, d.baseAvgMinutes);
      insertDoctor.run({
        id: d.id,
        clinicId: d.clinicId,
        specialtyId: d.specialtyId,
        name: d.name,
        credentials: d.credentials,
        roomNumber: d.roomNumber,
        consultationFee: d.consultationFee,
        baseAvgMinutes: d.baseAvgMinutes,
        ewmaMinutes: ewma,
        recentDurationsJson: JSON.stringify(d.recentDurations),
        morningStatus: d.morningStatus,
        eveningStatus: d.eveningStatus,
        morningDelayMinutes: d.morningDelayMinutes,
        eveningDelayMinutes: d.eveningDelayMinutes,
      });
    }

    const baseTime = new Date('2026-11-20T08:00:00.000Z').getTime();
    seed.sampleTokens.forEach((t, idx) => {
      const createdAt = new Date(baseTime + idx * 60_000).toISOString();
      const apptRes = insertAppointment.run({
        clinicId: t.clinicId,
        doctorId: t.doctorId,
        shift: t.shift,
        patientName: t.patientName,
        patientPhone: t.patientPhone,
        symptoms: 'Scheduled outpatient consultation',
        bookedAt: createdAt,
      });

      const appointmentId = Number(apptRes.lastInsertRowid);
      const isCompleted = t.status === 'completed';
      const isActive = t.status === 'in_consultation';

      insertToken.run({
        appointmentId,
        clinicId: t.clinicId,
        doctorId: t.doctorId,
        shift: t.shift,
        tokenNumber: t.tokenNumber,
        status: t.status,
        checkedIn: isCompleted || isActive ? 1 : 0,
        calledAt: isCompleted || isActive ? createdAt : null,
        completedAt: isCompleted ? createdAt : null,
        consultationDuration: t.duration,
        createdAt,
      });
    });

    for (const w of seed.historicalWaitLogs) {
      insertWaitLog.run(w);
    }

    const now = new Date().toISOString();
    const docHash = bcrypt.hashSync('Doctor@123', 8);
    const triageHash = bcrypt.hashSync('Triage@123', 8);
    const patientHash = bcrypt.hashSync('Patient@123', 8);

    insertUser.run({
      email: 'dr.mehta@queuezero.clinic',
      passwordHash: docHash,
      name: 'Dr. Arjun Mehta',
      role: 'doctor',
      doctorId: 1,
      createdAt: now,
    });
    insertUser.run({
      email: 'dr.sharma@queuezero.clinic',
      passwordHash: docHash,
      name: 'Dr. Priya Sharma',
      role: 'doctor',
      doctorId: 2,
      createdAt: now,
    });
    insertUser.run({
      email: 'triage@queuezero.clinic',
      passwordHash: triageHash,
      name: 'Triage Desk Lead',
      role: 'triage_staff',
      doctorId: null,
      createdAt: now,
    });
    insertUser.run({
      email: 'patient@queuezero.clinic',
      passwordHash: patientHash,
      name: 'Patient A',
      role: 'patient',
      doctorId: null,
      createdAt: now,
    });
  });

  runSeed();
}
