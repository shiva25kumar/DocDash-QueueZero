import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import { createApp } from './server/app.ts';
import { logger } from './server/logger.ts';

async function startServer() {
  const port = Number(process.env.PORT ?? 3000);
  const isProd = process.env.NODE_ENV === 'production';

  const { app, server } = createApp();

  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    if (fs.existsSync(distDir)) {
      app.use(express.static(distDir));
      app.get('*', (req, res, next) => {
        if (req.path.startsWith('/api')) {
          next();
          return;
        }
        res.sendFile(path.join(distDir, 'index.html'));
      });
    }
  }

  server.listen(port, '0.0.0.0', () => {
    logger.info({ port, mode: isProd ? 'production' : 'development' }, 'DocDash – QueueZero Clinic server listening');
  });
}

startServer().catch((err) => {
  logger.error({ err }, 'Fatal error starting server');
  process.exit(1);
});
