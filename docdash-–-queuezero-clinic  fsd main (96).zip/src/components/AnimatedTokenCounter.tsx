import { AnimatePresence, motion } from 'motion/react';

interface AnimatedTokenCounterProps {
  value: number | string;
  prefix?: string;
  suffix?: string;
  className?: string;
}

export function AnimatedTokenCounter({
  value,
  prefix = '',
  suffix = '',
  className = '',
}: AnimatedTokenCounterProps) {
  return (
    <span className={`inline-flex items-baseline overflow-hidden font-mono tabular-nums ${className}`}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={String(value)}
          initial={{ y: 8, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: -8, opacity: 0 }}
          transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
          className="inline-block"
        >
          {prefix}
          {value}
          {suffix}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}
