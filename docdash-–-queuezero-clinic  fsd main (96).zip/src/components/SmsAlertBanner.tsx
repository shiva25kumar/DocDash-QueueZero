import { useEffect, useRef, useState } from 'react';
import { BellRing, MessageSquare, Check } from 'lucide-react';
import type { PatientAppointmentDetail } from '../types/clinic.ts';

interface SimulatedSmsRecord {
  key: string;
  tokenNumber: number;
  patientName: string;
  patientPhone: string;
  clinicName: string;
  doctorName: string;
  message: string;
  triggeredAt: string;
  patientsAhead: number;
}

interface SmsAlertBannerProps {
  appointments: PatientAppointmentDetail[];
}

export function SmsAlertBanner({ appointments }: SmsAlertBannerProps) {
  const triggeredKeysRef = useRef<Set<string>>(new Set());
  const [smsLog, setSmsLog] = useState<SimulatedSmsRecord[]>([]);

  const activeAlerts = appointments.filter(
    (appt) =>
      appt.status === 'waiting' &&
      appt.shouldTriggerSmsAlert &&
      appt.patientsAhead !== null &&
      appt.patientsAhead > 0 &&
      appt.patientsAhead <= 2
  );

  useEffect(() => {
    const newRecords: SimulatedSmsRecord[] = [];
    for (const appt of activeAlerts) {
      const dedupeKey = `sms-token-${appt.tokenId}`;
      if (!triggeredKeysRef.current.has(dedupeKey)) {
        triggeredKeysRef.current.add(dedupeKey);
        newRecords.push({
          key: dedupeKey,
          tokenNumber: appt.tokenNumber,
          patientName: appt.patientName,
          patientPhone: appt.patientPhone,
          clinicName: appt.clinic.name,
          doctorName: appt.doctor.name,
          message: 'Please arrive at the clinic now!',
          triggeredAt: new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          }),
          patientsAhead: appt.patientsAhead ?? 2,
        });
      }
    }

    if (newRecords.length > 0) {
      setSmsLog((prev) => [...newRecords, ...prev]);
    }
  }, [activeAlerts]);

  if (activeAlerts.length === 0 && smsLog.length === 0) {
    return (
      <section
        aria-label="SMS Notification Simulator"
        data-testid="sms-simulator-idle"
        className="rounded-xl border border-slate-200 bg-white p-5"
      >
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-600">
              <MessageSquare className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-sm font-semibold text-slate-900">
                SMS Arrival Notification Simulator
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                Monitoring active token positions. An arrival alert will trigger automatically when
                your token is exactly 2 positions away.
              </p>
            </div>
          </div>
          <span className="text-xs font-medium text-slate-500 whitespace-nowrap">
            Standing By
          </span>
        </div>
      </section>
    );
  }

  return (
    <section
      aria-label="SMS Notification Simulator"
      data-testid="sms-simulator-active"
      className="space-y-3"
    >
      {activeAlerts.map((appt) => (
        <div
          key={appt.tokenId}
          role="alert"
          data-testid={`sms-alert-token-${appt.tokenNumber}`}
          className="rounded-xl border border-amber-300 bg-amber-50 p-5 text-amber-950"
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3.5">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-amber-600 text-white">
                <BellRing className="h-5 w-5" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-amber-800">
                  <span>Simulated SMS Dispatch</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">To: {appt.patientPhone}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">Token #{appt.tokenNumber}</span>
                </div>
                <p className="mt-1 font-display text-lg font-bold text-amber-950">
                  Please arrive at the clinic now!
                </p>
                <p className="mt-0.5 text-sm text-amber-900">
                  {appt.doctor.name} ({appt.clinic.name}) is currently serving Token #
                  {appt.currentlyServingTokenNumber ?? '—'}. Only{' '}
                  <span className="font-mono font-semibold tabular-nums">
                    {appt.patientsAhead}
                  </span>{' '}
                  {appt.patientsAhead === 1 ? 'patient' : 'patients'} ahead (estimated{' '}
                  <span className="font-mono font-semibold tabular-nums">
                    {appt.estimatedWaitMinutes}
                  </span>{' '}
                  min).
                </p>
              </div>
            </div>

            <div className="inline-flex items-center gap-1.5 self-start rounded-lg border border-amber-300 bg-white px-3 py-1.5 text-xs font-semibold text-amber-900 sm:self-center whitespace-nowrap">
              <Check className="h-3.5 w-3.5 text-amber-700" />
              SMS Delivered
            </div>
          </div>
        </div>
      ))}

      {smsLog.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white px-5 py-3.5">
          <div className="flex items-center justify-between text-xs font-medium text-slate-500">
            <span>Dispatched SMS Notification History (deduplicated per token)</span>
            <span className="font-mono tabular-nums">{smsLog.length} sent</span>
          </div>
          <ul className="mt-2 divide-y divide-slate-100">
            {smsLog.slice(0, 3).map((entry) => (
              <li
                key={entry.key}
                className="flex flex-wrap items-center justify-between gap-2 py-2 text-xs text-slate-700"
              >
                <span>
                  <span className="font-mono font-semibold tabular-nums text-slate-900">
                    Token #{entry.tokenNumber}
                  </span>{' '}
                  · {entry.patientPhone} · &ldquo;{entry.message}&rdquo;
                </span>
                <span className="font-mono tabular-nums text-slate-500">
                  {entry.triggeredAt}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </section>
  );
}
