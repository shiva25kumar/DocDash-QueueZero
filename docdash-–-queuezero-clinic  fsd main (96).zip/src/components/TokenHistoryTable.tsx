import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { PaginatedTokenHistory } from '../types/clinic.ts';

interface TokenHistoryTableProps {
  history: PaginatedTokenHistory | null;
  loading: boolean;
  statusFilter: string;
  onStatusFilterChange: (status: string) => void;
  onPageChange: (page: number) => void;
}

export function TokenHistoryTable({
  history,
  loading,
  statusFilter,
  onStatusFilterChange,
  onPageChange,
}: TokenHistoryTableProps) {
  return (
    <section className="rounded-xl border border-slate-200 bg-white p-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-display text-lg font-bold text-slate-900">
            Paginated Queue Token History
          </h2>
          <p className="mt-0.5 text-sm text-slate-600">
            Complete audit record of outpatient queue tokens across clinic branches.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label htmlFor="history-status-filter" className="text-xs font-medium text-slate-600">
            Status:
          </label>
          <select
            id="history-status-filter"
            value={statusFilter}
            onChange={(e) => onStatusFilterChange(e.target.value)}
            className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
          >
            <option value="all">All Statuses</option>
            <option value="waiting">Waiting</option>
            <option value="in_consultation">In Consultation</option>
            <option value="completed">Completed</option>
            <option value="holding">Holding (Absent)</option>
          </select>
        </div>
      </div>

      <div className="mt-5 overflow-x-auto">
        <table className="w-full min-w-[680px] border-collapse text-left text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
              <th className="py-2.5 pr-4">Token</th>
              <th className="py-2.5 pr-4">Patient</th>
              <th className="py-2.5 pr-4">Doctor</th>
              <th className="py-2.5 pr-4">Clinic</th>
              <th className="py-2.5 pr-4">Shift</th>
              <th className="py-2.5 pr-4">Status</th>
              <th className="py-2.5 text-right">Duration</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading && !history && (
              <tr>
                <td colSpan={7} className="py-8 text-center text-sm text-slate-500">
                  Loading token history...
                </td>
              </tr>
            )}
            {history && history.items.length === 0 && (
              <tr>
                <td colSpan={7} className="py-8 text-center text-sm text-slate-500">
                  No token records match the selected filter.
                </td>
              </tr>
            )}
            {history?.items.map((item) => (
              <tr key={item.id} className="hover:bg-slate-50">
                <td className="py-3 pr-4 font-mono font-semibold tabular-nums text-slate-900">
                  #{item.tokenNumber}
                  {item.isEmergency ? (
                    <span className="ml-2 text-xs font-semibold text-red-700">Emergency</span>
                  ) : null}
                </td>
                <td className="py-3 pr-4 text-slate-900">
                  <div className="font-medium">{item.patientName}</div>
                  <div className="font-mono text-xs tabular-nums text-slate-500">
                    {item.patientPhone}
                  </div>
                </td>
                <td className="py-3 pr-4 text-slate-700">
                  <div>{item.doctorName}</div>
                  <div className="text-xs text-slate-500">{item.specialtyName}</div>
                </td>
                <td className="py-3 pr-4 text-slate-600">{item.clinicName}</td>
                <td className="py-3 pr-4 capitalize text-slate-600">{item.shift}</td>
                <td className="py-3 pr-4">
                  <span
                    className={`text-xs font-semibold capitalize ${
                      item.status === 'in_consultation'
                        ? 'text-emerald-700'
                        : item.status === 'holding'
                        ? 'text-amber-700'
                        : item.status === 'waiting'
                        ? 'text-teal-700'
                        : 'text-slate-600'
                    }`}
                  >
                    {item.status.replace('_', ' ')}
                  </span>
                </td>
                <td className="py-3 text-right font-mono tabular-nums text-slate-700">
                  {item.consultationDuration ? `${item.consultationDuration}m` : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {history && (
        <div className="mt-4 flex flex-col gap-3 border-t border-slate-100 pt-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-xs text-slate-600 font-mono tabular-nums">
            Page {history.page} of {history.totalPages} · {history.total} total tokens
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={history.page <= 1}
              onClick={() => onPageChange(history.page - 1)}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-45"
            >
              <ChevronLeft className="h-4 w-4" />
              Previous
            </button>
            <button
              type="button"
              disabled={history.page >= history.totalPages}
              onClick={() => onPageChange(history.page + 1)}
              className="inline-flex items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-45"
            >
              Next
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
