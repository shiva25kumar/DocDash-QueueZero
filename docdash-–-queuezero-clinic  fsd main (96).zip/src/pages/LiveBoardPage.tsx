import { useCallback, useEffect, useState } from 'react';
import { RefreshCw } from 'lucide-react';
import type { Clinic, DoctorQueueBoard, ShiftType } from '../types/clinic.ts';
import { fetchQueueBoards } from '../services/apiClient.ts';
import { useQueueSync } from '../hooks/useQueueSync.ts';
import { AnimatedTokenCounter } from '../components/AnimatedTokenCounter.tsx';

interface LiveBoardPageProps {
  clinics: Clinic[];
}

export function LiveBoardPage({ clinics }: LiveBoardPageProps) {
  const [clinicId, setClinicId] = useState<number | null>(null);
  const [shift, setShift] = useState<ShiftType>('morning');
  const [boards, setBoards] = useState<DoctorQueueBoard[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadBoards = useCallback(async () => {
    try {
      const data = await fetchQueueBoards({
        clinicId: clinicId ?? undefined,
        shift,
      });
      setBoards(data);
      setError(null);
    } catch {
      setError('Unable to refresh live waiting room boards.');
    } finally {
      setLoading(false);
    }
  }, [clinicId, shift]);

  useEffect(() => {
    void loadBoards();
  }, [loadBoards]);

  const { wsConnected } = useQueueSync(() => {
    void loadBoards();
  }, 3000);

  return (
    <div className="space-y-6">
      <section className="rounded-xl border border-slate-200 bg-white p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="font-display text-2xl font-bold text-slate-900">
              Live Waiting Room Queue Board
            </h1>
            <p className="mt-1 text-sm text-slate-600">
              Real-time consultation status, currently serving tokens, and EWMA wait projections.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <label htmlFor="board-clinic-filter" className="sr-only">
              Clinic Branch Filter
            </label>
            <select
              id="board-clinic-filter"
              value={clinicId ?? ''}
              onChange={(e) => setClinicId(e.target.value ? Number(e.target.value) : null)}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              <option value="">All Clinics</option>
              {clinics.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
              {(['morning', 'evening'] as ShiftType[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setShift(s)}
                  className={`rounded-md px-3 py-1 text-xs font-medium capitalize transition-colors ${
                    shift === s
                      ? 'bg-white text-slate-950 font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={() => void loadBoards()}
              aria-label="Refresh queue board"
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              {wsConnected ? 'Live Sync' : 'Polling 3s'}
            </button>
          </div>
        </div>
      </section>

      {error && (
        <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          {error}
        </div>
      )}

      {loading && boards.length === 0 ? (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-64 animate-pulse rounded-xl border border-slate-200 bg-white p-6"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-2">
          {boards.map((board) => {
            const statusTone =
              board.doctorStatus === 'Delayed'
                ? 'text-amber-700'
                : board.doctorStatus === 'On Break'
                ? 'text-slate-500'
                : 'text-emerald-700';

            return (
              <article
                key={`${board.doctor.id}-${board.shift}`}
                data-testid={`live-board-doctor-${board.doctor.id}`}
                className="rounded-xl border border-slate-200 bg-white p-6"
              >
                <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-100 pb-4">
                  <div>
                    <h2 className="font-display text-lg font-bold text-slate-900">
                      {board.doctor.name}
                    </h2>
                    <p className="mt-0.5 text-xs text-slate-600">
                      {board.doctor.specialtyName} · {board.doctor.clinicName} ·{' '}
                      {board.doctor.roomNumber}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className={`text-xs font-semibold ${statusTone}`}>
                      {board.doctorStatus}
                      {board.offsetDelayMinutes > 0 ? ` (+${board.offsetDelayMinutes}m)` : ''}
                    </span>
                    <div className="mt-0.5 font-mono text-xs tabular-nums text-slate-500">
                      EWMA {board.ewmaMinutes.toFixed(1)}m / visit
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-4 rounded-lg bg-slate-50 p-4">
                  <div>
                    <div className="text-xs text-slate-500">Now Serving</div>
                    <div className="mt-1 text-2xl font-bold text-teal-800">
                      {board.activeToken ? (
                        <AnimatedTokenCounter
                          value={board.activeToken.tokenNumber}
                          prefix="#"
                        />
                      ) : (
                        <span className="font-mono text-slate-400">—</span>
                      )}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Next in Line</div>
                    <div className="mt-1 text-2xl font-bold text-slate-900">
                      {board.nextToken ? (
                        <AnimatedTokenCounter
                          value={board.nextToken.tokenNumber}
                          prefix="#"
                        />
                      ) : (
                        <span className="font-mono text-slate-400">—</span>
                      )}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">Waiting Count</div>
                    <div className="mt-1 font-mono text-2xl font-bold tabular-nums text-slate-900">
                      {board.waitingTokens.length}
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <h3 className="text-xs font-semibold text-slate-600">
                    Upcoming Waiting Queue
                  </h3>
                  {board.waitingTokens.length === 0 ? (
                    <p className="mt-2 text-xs text-slate-500">
                      No patients currently waiting in this shift.
                    </p>
                  ) : (
                    <ul className="mt-2 divide-y divide-slate-100">
                      {board.waitingTokens.slice(0, 5).map((token) => (
                        <li
                          key={token.id}
                          className="flex items-center justify-between py-2 text-sm"
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="font-mono font-bold tabular-nums text-slate-900">
                              #{token.tokenNumber}
                            </span>
                            <span className="text-slate-700">{token.patientName}</span>
                            {token.isEmergency && (
                              <span className="text-xs font-semibold text-red-700">
                                Emergency Priority
                              </span>
                            )}
                          </div>
                          <div className="font-mono text-xs tabular-nums text-slate-600">
                            {token.estimatedWaitMinutes}m wait
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
}
