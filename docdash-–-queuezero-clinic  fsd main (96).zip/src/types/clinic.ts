export type ShiftType = 'morning' | 'evening';

export type DoctorStatusType = 'In Consultation' | 'On Break' | 'Delayed';

export type TokenStatusType =
  | 'waiting'
  | 'in_consultation'
  | 'completed'
  | 'holding'
  | 'cancelled';

export type UserRole = 'patient' | 'doctor' | 'triage_staff';

export interface AuthUser {
  id: number;
  email: string;
  name: string;
  role: UserRole;
  doctorId: number | null;
}

export interface Clinic {
  id: number;
  name: string;
  code: string;
  address: string;
  neighborhood: string;
  phone: string;
  latitude: number;
  longitude: number;
}

export interface Specialty {
  id: number;
  name: string;
  description: string;
}

export interface Doctor {
  id: number;
  clinicId: number;
  clinicName: string;
  clinicNeighborhood: string;
  clinicAddress: string;
  clinicLatitude: number;
  clinicLongitude: number;
  specialtyId: number;
  specialtyName: string;
  name: string;
  credentials: string;
  roomNumber: string;
  consultationFee: number;
  baseAvgMinutes: number;
  ewmaMinutes: number;
  recentDurations: number[];
  morningStatus: DoctorStatusType;
  eveningStatus: DoctorStatusType;
  morningDelayMinutes: number;
  eveningDelayMinutes: number;
}

export interface QueueTokenItem {
  id: number;
  appointmentId: number;
  clinicId: number;
  doctorId: number;
  shift: ShiftType;
  tokenNumber: number;
  status: TokenStatusType;
  isEmergency: boolean;
  priorityRank: number;
  patientName: string;
  patientPhone: string;
  checkedIn: boolean;
  checkedInAt: string | null;
  calledAt: string | null;
  completedAt: string | null;
  consultationDuration: number | null;
  smsAlertSent: boolean;
  createdAt: string;
}

export interface ComputedTokenSnapshot extends QueueTokenItem {
  queuePosition: number | null;
  patientsAhead: number | null;
  estimatedWaitMinutes: number | null;
  shouldTriggerSmsAlert: boolean;
}

export interface DoctorQueueBoard {
  doctor: Doctor;
  shift: ShiftType;
  doctorStatus: DoctorStatusType;
  offsetDelayMinutes: number;
  ewmaMinutes: number;
  activeToken: ComputedTokenSnapshot | null;
  nextToken: ComputedTokenSnapshot | null;
  waitingTokens: ComputedTokenSnapshot[];
  holdingTokens: QueueTokenItem[];
  completedCount: number;
  nextAvailableTokenNumber: number;
}

export interface PrescriptionAttachment {
  id: number;
  appointmentId: number;
  doctorId: number;
  fileName: string;
  mimeType: string;
  fileSize: number;
  notes: string;
  uploadedAt: string;
}

export interface PatientAppointmentDetail {
  appointmentId: number;
  tokenId: number;
  tokenNumber: number;
  shift: ShiftType;
  status: TokenStatusType;
  isEmergency: boolean;
  patientName: string;
  patientPhone: string;
  symptoms: string;
  bookedAt: string;
  checkedIn: boolean;
  checkedInAt: string | null;
  smsAlertSent: boolean;
  clinic: Clinic;
  doctor: {
    id: number;
    name: string;
    credentials: string;
    specialtyName: string;
    roomNumber: string;
    consultationFee: number;
    ewmaMinutes: number;
    status: DoctorStatusType;
    offsetDelayMinutes: number;
  };
  currentlyServingTokenNumber: number | null;
  queuePosition: number | null;
  patientsAhead: number | null;
  estimatedWaitMinutes: number | null;
  shouldTriggerSmsAlert: boolean;
  prescription: PrescriptionAttachment | null;
}

export interface HeatmapCell {
  dayOfWeek: string;
  dayIndex: number;
  hourSlot: string;
  hourNum: number;
  avgWaitMinutes: number;
  sampleCount: number;
}

export interface PaginatedTokenHistory {
  items: Array<
    QueueTokenItem & {
      doctorName: string;
      specialtyName: string;
      clinicName: string;
    }
  >;
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface AuditLogEntry {
  id: number;
  event: string;
  actorRole: string;
  actorName: string;
  doctorId: number | null;
  tokenNumber: number | null;
  details: string;
  createdAt: string;
}
