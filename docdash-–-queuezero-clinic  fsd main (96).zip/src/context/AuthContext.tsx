import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react';
import type { AuthUser } from '../types/clinic.ts';
import {
  ensureCsrfToken,
  fetchCurrentUser,
  loginAccount,
  logoutAccount,
} from '../services/apiClient.ts';

interface AuthContextValue {
  user: AuthUser | null;
  authLoading: boolean;
  bookedIds: number[];
  rememberBookedAppointment: (id: number) => void;
  login: (email: string, password: string) => Promise<AuthUser>;
  logout: () => Promise<void>;
  refreshUser: () => Promise<void>;
}

const BOOKED_STORAGE_KEY = 'docdash_booked_appointment_ids';

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [bookedIds, setBookedIds] = useState<number[]>(() => {
    try {
      const raw = localStorage.getItem(BOOKED_STORAGE_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw) as unknown;
      if (Array.isArray(parsed)) {
        return parsed.filter((n): n is number => typeof n === 'number' && Number.isInteger(n));
      }
      return [];
    } catch {
      return [];
    }
  });

  const refreshUser = useCallback(async () => {
    try {
      await ensureCsrfToken();
      const current = await fetchCurrentUser();
      setUser(current);
    } catch {
      setUser(null);
    } finally {
      setAuthLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshUser();
  }, [refreshUser]);

  const rememberBookedAppointment = useCallback((id: number) => {
    setBookedIds((prev) => {
      const next = [id, ...prev.filter((item) => item !== id)].slice(0, 12);
      try {
        localStorage.setItem(BOOKED_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // Ignore storage errors
      }
      return next;
    });
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const loggedIn = await loginAccount(email, password);
    setUser(loggedIn);
    return loggedIn;
  }, []);

  const logout = useCallback(async () => {
    await logoutAccount();
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        authLoading,
        bookedIds,
        rememberBookedAppointment,
        login,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return ctx;
}
