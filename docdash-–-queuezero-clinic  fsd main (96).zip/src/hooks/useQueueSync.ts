import { useEffect, useRef, useState } from 'react';

export function useQueueSync(onSync: () => void, pollIntervalMs = 3000) {
  const onSyncRef = useRef(onSync);
  onSyncRef.current = onSync;
  const [wsConnected, setWsConnected] = useState(false);

  useEffect(() => {
    let closed = false;
    let socket: WebSocket | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      if (closed) return;
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const url = `${protocol}//${window.location.host}/ws/queue`;

      try {
        socket = new WebSocket(url);

        socket.onopen = () => {
          if (!closed) setWsConnected(true);
        };

        socket.onmessage = (event) => {
          try {
            const msg = JSON.parse(String(event.data)) as { type?: string };
            if (msg.type === 'queue:updated') {
              onSyncRef.current();
            }
          } catch {
            // Ignore malformed socket frames
          }
        };

        socket.onclose = () => {
          if (!closed) {
            setWsConnected(false);
            reconnectTimer = setTimeout(connect, 2500);
          }
        };

        socket.onerror = () => {
          if (!closed) {
            setWsConnected(false);
          }
        };
      } catch {
        setWsConnected(false);
      }
    };

    connect();

    // 3-second lightweight HTTP polling fallback ensures guaranteed synchronization
    const pollTimer = setInterval(() => {
      onSyncRef.current();
    }, pollIntervalMs);

    return () => {
      closed = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      clearInterval(pollTimer);
      if (socket && socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [pollIntervalMs]);

  return { wsConnected };
}
